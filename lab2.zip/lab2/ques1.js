
var count=[];
alert("enter Five cuontries you like OR visited ");

for(i=1;i<=5;i++)
{
  count[i]=prompt(" enter country no:"+ i);
}

orderedList();




function add()
{
  var item=prompt("Enter country name");
  count.push(item);

}
function del() {
  var ch=prompt("a. to Delete last item\n b. to Delete by index")
  switch (ch) {
    case "a":
     count.pop();
     break;
     case "b":
     var del= prompt("enter index value");
    count.splice(del,1);
     break;
    default:
    break;
  }

}

function orderedList()
{
var html = "";
for (var i =1; i <count.length; i++) {
    html += "<li>" + count[i]+ "</li>";
}
document.getElementById("cl").innerHTML=html;

}
function ex()
{
  var c=prompt("wish to exit y.yes n.no");
  switch (c) {
    case "n":
      enterpoint();
      break;
    default:
       break;
  }

}
